#!/bin/bash

array[0] =
array[1] = B
array[2] = C
array[3] = D
echo "num :${#array[@]}"
echo "num : ${array[*]}"
echo " ${array[@]} \n"

